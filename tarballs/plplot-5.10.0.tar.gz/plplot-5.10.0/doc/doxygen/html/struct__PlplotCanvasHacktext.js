var struct__PlplotCanvasHacktext =
[
    [ "fill_color", "struct__PlplotCanvasHacktext.html#a069d2955ab4655c20978a32e453f139f", null ],
    [ "fill_pixel", "struct__PlplotCanvasHacktext.html#aca6cad78a318081c75361890dd3141bc", null ],
    [ "fill_rgba", "struct__PlplotCanvasHacktext.html#a42583d4c9a7dcef3b03d2dd3e7b5cd2d", null ],
    [ "fill_set", "struct__PlplotCanvasHacktext.html#a402e21892d15b29de7278bce0bb0db30", null ],
    [ "item", "struct__PlplotCanvasHacktext.html#a244c7bd1cb8825509b83adea8c5bd8fe", null ],
    [ "priv", "struct__PlplotCanvasHacktext.html#aab7a9399f86520dc69d3b79577ece145", null ],
    [ "size", "struct__PlplotCanvasHacktext.html#a76879a1ea61f0ba9b33d0ffc10addbb0", null ],
    [ "text", "struct__PlplotCanvasHacktext.html#aefbb0123513c06b1502be2a66d79706c", null ],
    [ "x", "struct__PlplotCanvasHacktext.html#a2b063de25910bcf6cb78fd807c7e6ea4", null ],
    [ "y", "struct__PlplotCanvasHacktext.html#a598dcc9fe9e94ec3aa6c8b2c458271d2", null ]
];